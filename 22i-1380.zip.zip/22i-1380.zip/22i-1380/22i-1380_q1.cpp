//#include <iostream>
//using namespace std;
//void SeatingArrangment()
//{
//	
//	cout << "Here is the seating arrangement" << endl;
//	for (int i = 0; i < 15; i++)
//	{
//		for (int j = 0; j < 15; j++)
//		{
//			cout<< "#";
//		}
//		cout << endl;
//	}
//}
//void SeatBooking()
//{
//	int row=0, column;
//	
//	while (row != -1)
//	{
//		cout << "Which row and column you want to book" << endl;
//		cin >> row >> column;
//		cout << "Here is the seating arrangement" << endl;
//		for (int i = 0; i < 15; i++)
//		{
//			for (int j = 0; j < 15; j++)
//			{
//				if (i == row && j == column)
//				{
//					cout << "*";
//				}
//				else
//				{
//					cout << "#";
//				}
//			}
//			cout << endl;
//		}
//		cout << "Do you want more seat? if not then press -1 for i" << endl;
//		
//	}
//}
//void AvailabileSeats()
//{
//	cout << "Now the available seats are" << endl;
//	for (int i = 0; i < 15; i++)
//	{
//		for (int j = 0; j < 15; j++)
//		{
//			cout << "#";
//		}
//		cout << endl;
//	}
//
//}
//void SeatCancelation()
//{
//	int row, column;
//	cout << "Enter the row or column you want to cancel" << endl;
//	cin >> row >> column;
//	for (int i = 0; i < 15; i++)
//	{
//		for (int j = 0; j < 15; j++)
//		{
//			cout << "#";
//		}
//		cout << endl;
//	}
//}
//
//int main()
//{
//	int choice;
//	cout << "Welcome to our MovieStop" << endl;
//	cout << "Here is the menu for the booking" << endl;
//	cout << "What you want to select?" << endl;
//	cout << "1. Seating Arrangement" << endl;
//	cout << "2. Seat Booking" << endl;
//	cout << "3. Availabile Seats" << endl;
//	cout << "4. Seat Cancelation" << endl;
//
//	cin >> choice;
//	if (choice == 1)
//	{
//		SeatingArrangment();
//	}
//	else if (choice == 2)
//	{
//		SeatBooking();
//	}
//	else if (choice == 3)
//	{
//		AvailabileSeats();
//	}
//	else if (choice == 4)
//	{
//		SeatCancelation();
//	}
//	
//	
//	return 0;
//}